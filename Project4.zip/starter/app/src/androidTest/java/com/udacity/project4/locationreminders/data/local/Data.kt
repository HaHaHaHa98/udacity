package com.udacity.project4.locationreminders.data.local

import com.udacity.project4.locationreminders.data.dto.ReminderDTO

object Data {
    val reminder1 = ReminderDTO(
        "The first location",
        "Opening times, ticket prices for individual and group visitors. Prices: 10.5 to 26.10 € maximum for adults, 2,6 to 13,10 € for children and young people.",
        "Eiffel tower",
        48.858093,
        2.294694
    )

    val reminder2 = ReminderDTO(
        "The second location",
        "The main walkway is on the eastern side, and is open for use by both pedestrians and bicycles in the morning to mid-afternoon during weekdays (5:00 a.m. to 3:30 p.m.)",
        "Golden Gate Bridge",
        37.8199286,
        -122.47825510000001
    )
    val remindersList = listOf(reminder1, reminder2)
}