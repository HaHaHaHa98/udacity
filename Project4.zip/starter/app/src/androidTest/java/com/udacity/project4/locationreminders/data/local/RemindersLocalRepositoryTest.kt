package com.udacity.project4.locationreminders.data.local

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import com.udacity.project4.locationreminders.data.dto.Result
import com.udacity.project4.locationreminders.data.local.Data.reminder1
import com.udacity.project4.locationreminders.data.local.Data.reminder2
import com.udacity.project4.locationreminders.data.local.Data.remindersList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.TestCoroutineDispatcher
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.CoreMatchers.instanceOf
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
//Medium Test to test the repository
@MediumTest
class RemindersLocalRepositoryTest {

    //TODO: Add testing implementation to the RemindersLocalRepository.kt
    @get:Rule
    var instantExecutorRule = InstantTaskExecutorRule()

    private lateinit var remindersLocalRepository: RemindersLocalRepository
    private lateinit var remindersDatabase: RemindersDatabase

    @Before
    fun createRepository() {
        remindersDatabase = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(), RemindersDatabase::class.java
        ).allowMainThreadQueries().build()
        remindersLocalRepository =
            RemindersLocalRepository(remindersDatabase.reminderDao(), TestCoroutineDispatcher())
    }

    @After
    fun clearRepository() {
        remindersDatabase.close()
    }

    //TODO: Add testing implementation to the Reminders LocalRepository.kt
    @Test
    fun getReminders() = runBlocking {
        remindersLocalRepository.run {
            saveReminder(reminder1)
            saveReminder(reminder2)
        }
        val result = remindersLocalRepository.getReminders() as Result.Success<List<ReminderDTO>>
        assertThat(result.data, `is`(remindersList))
    }

    @Test
    fun deleteReminder_and_getReminders() = runBlocking {
        remindersLocalRepository.deleteAllReminders()
        val result =
            remindersLocalRepository.getReminders() as Result.Success<List<ReminderDTO>>
        assertThat(result.data.isEmpty(), `is`(true))
    }


    @Test
    fun saveReminder_and_getReminder() = runBlocking {
        remindersLocalRepository.saveReminder(reminder1)
        val result =
            remindersLocalRepository.getReminder(reminder1.id) as Result.Success<ReminderDTO>
        assertThat(result.data, `is`(reminder1))
    }

    @Test
    fun getReminder_ReturnNotFoundError() = runBlocking {
        remindersLocalRepository.deleteAllReminders()
        val result = remindersLocalRepository.getReminder(reminder1.id) as Result.Error
        assertThat(result.message, `is`("Reminder not found!"))
    }

}