package com.udacity.project4.locationreminders.data.local

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.SmallTest;
import com.udacity.project4.locationreminders.data.local.Data.reminder1
import com.udacity.project4.locationreminders.data.local.Data.reminder2
import com.udacity.project4.locationreminders.data.local.Data.remindersList

import org.junit.Before;
import org.junit.Rule;
import org.junit.runner.RunWith;

import kotlinx.coroutines.ExperimentalCoroutinesApi;
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.CoreMatchers.*
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Test

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
//Unit test the DAO
@SmallTest
class RemindersDaoTest {

    //TODO: Add testing implementation to the RemindersDao.kt
    @get: Rule
    var instantExecutorRule = InstantTaskExecutorRule()

    private lateinit var database: RemindersDatabase

    private lateinit var remindersDao: RemindersDao

    @Before
    fun init() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(), RemindersDatabase::class.java

        ).allowMainThreadQueries().build()
        remindersDao = database.reminderDao()
    }

    @After
    fun clean() {
        database.close()
    }

    @Test
    fun getReminders() = runBlockingTest {
        // save reminder1, reminder2
        remindersDao.run {
            saveReminder(reminder1)
            saveReminder(reminder2)
        }
        // get reminders list
        val result = remindersDao.getReminders()
        // verify result == expected
        assertThat(result, `is`(remindersList))
    }

    @Test
    fun deleteReminder_and_getReminders() = runBlocking {
        //clear data
        remindersDao.deleteAllReminders()
        val result = remindersDao.getReminders()
        // verify result is empty
        assertThat(result.isEmpty(), `is`(true))
    }


    @Test
    fun saveReminder_and_getReminderByIdSucceed() = runBlockingTest {
        // save reminder1
        remindersDao.saveReminder(reminder1)
        // find item by reminder1's id
        val result = remindersDao.getReminderById(reminder1.id)
        // verify result is reminder1
        assertThat(result, `is`(reminder1))
    }

    @Test
    fun getReminderById_getReminderByIdNull() = runBlockingTest {
        // clear data
        remindersDao.deleteAllReminders()
        // find item by reminder1's id
        val result = remindersDao.getReminderById(reminder1.id)
        // verify result is null
        assertThat(result, `is`(nullValue()))
    }
}