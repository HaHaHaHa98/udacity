package com.udacity.project4.locationreminders.reminderslist

import com.udacity.project4.R
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import java.io.Serializable
import java.util.*

/**
 * data class acts as a data mapper between the DB and the UI
 */
data class ReminderDataItem(
    var title: String?,
    var description: String?,
    var location: String?,
    var latitude: Double?,
    var longitude: Double?,
    val id: String = UUID.randomUUID().toString()
) : Serializable {

    fun getLocationValue(): String {
        if (location == defaultLocation || location.isNullOrEmpty()) {
            return String.format(Locale.getDefault(), locationFormat, latitude, longitude)
        }
        return location!!
    }

    companion object {
        fun convertFromDtoToDataItem(dto: ReminderDTO): ReminderDataItem {
            return ReminderDataItem(
                title = dto.title,
                location = dto.location,
                description = dto.description,
                latitude = dto.latitude,
                longitude = dto.longitude,
                id = dto.id
            )
        }

        private const val defaultLocation = "Dropped Pin"
        private const val locationFormat = "Lat: %1\$.5f\nLong: %2\$.5f"
    }
}