package com.udacity.project4.locationreminders.reminderslist

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.udacity.project4.locationreminders.MainCoroutineRule
import com.udacity.project4.locationreminders.data.FakeDataSource
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import com.udacity.project4.locationreminders.getOrAwaitValue
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.core.Is.`is`
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.core.context.stopKoin

@RunWith(AndroidJUnit4::class)
@ExperimentalCoroutinesApi
class RemindersListViewModelTest {

    //TODO: provide testing to the RemindersListViewModel and its live data objects

    // Executes each task synchronously using Architecture Components.
    @get: Rule
    var instantExecutorRule = InstantTaskExecutorRule()

    // Set the main coroutines dispatcher for unit testing.
    @ExperimentalCoroutinesApi
    @get: Rule
    var mainCoroutineRule = MainCoroutineRule()

    //TODO: provide testing to the RemindersListViewModel and its live data objects
    private lateinit var fakeDataSource: FakeDataSource
    private lateinit var remindersListViewModel: RemindersListViewModel

    private val reminder1 = ReminderDTO(
        "The first Location",
        "Opening times, ticket prices for individual and group visitors. Prices: 10.5 to 26.10 € maximum for adults, 2,6 to 13,10 € for children and young people.",
        "Eiffel tower",
        48.858093,
        2.294694
    )

    private val reminder2 = ReminderDTO(
        "The second Location",
        "The main walkway is on the eastern side, and is open for use by both pedestrians and bicycles in the morning to mid-afternoon during weekdays (5:00 a.m. to 3:30 p.m.)",
        "Golden Gate Bridge",
        37.8199286,
        -122.47825510000001
    )

    @Before
    fun setupViewModel() {
        fakeDataSource = FakeDataSource()
        remindersListViewModel =
            RemindersListViewModel(ApplicationProvider.getApplicationContext(), fakeDataSource)
    }

    @After
    fun reset() {
        stopKoin()
    }

    @Test
    fun loadReminders_correctData() = mainCoroutineRule.runBlockingTest {
        // Save reminder1, reminder2
        fakeDataSource.run {
            saveReminder(reminder1)
            saveReminder(reminder2)
        }
        // load reminders list
        remindersListViewModel.loadReminders()
        // verify result
        assertThat(
            remindersListViewModel.remindersList.getOrAwaitValue(), `is`(
                listOf(
                    ReminderDataItem.convertFromDtoToDataItem(reminder1),
                    ReminderDataItem.convertFromDtoToDataItem(reminder2)
                )
            )
        )
    }

    @Test
    fun loadReminders_errorMessage() {
        // set status to fake data return error
        fakeDataSource.setReturnError(true)
        // load reminders list
        remindersListViewModel.loadReminders()
        // verify showSnackBar = Reminders not found
        assertThat(
            remindersListViewModel.showSnackBar.getOrAwaitValue(), `is`("Reminders not found")
        )
        // verify showNoData = true
        assertThat(
            remindersListViewModel.showNoData.getOrAwaitValue(), `is`(true)
        )
    }

    @Test
    fun loadReminders_showLoadingReminders() = mainCoroutineRule.runBlockingTest {
        mainCoroutineRule.pauseDispatcher()
        fakeDataSource.saveReminder(reminder1)
        remindersListViewModel.loadReminders()
        assertThat(remindersListViewModel.showLoading.getOrAwaitValue(), `is`(true))
        mainCoroutineRule.resumeDispatcher()
        assertThat(remindersListViewModel.showLoading.getOrAwaitValue(), `is`(false))
    }
}