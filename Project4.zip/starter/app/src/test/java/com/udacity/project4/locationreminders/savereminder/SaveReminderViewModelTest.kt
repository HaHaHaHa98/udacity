package com.udacity.project4.locationreminders.savereminder

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.udacity.project4.locationreminders.MainCoroutineRule
import com.udacity.project4.locationreminders.data.FakeDataSource
import com.udacity.project4.locationreminders.getOrAwaitValue
import com.udacity.project4.locationreminders.reminderslist.ReminderDataItem
import com.udacity.project4.R
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import org.hamcrest.MatcherAssert.assertThat
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.core.Is.`is`
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.core.context.stopKoin


@RunWith(AndroidJUnit4::class)
@ExperimentalCoroutinesApi
class SaveReminderViewModelTest {
    @get: Rule
    var instantExecutorRule = InstantTaskExecutorRule()

    @get: Rule
    var mainCoroutineRule = MainCoroutineRule()


    //TODO: provide testing to the SaveReminderView and its live data objects
    private lateinit var fakeDataSource: FakeDataSource
    private lateinit var saveReminderViewModel: SaveReminderViewModel

    @Before
    fun setupViewModel() {
        fakeDataSource = FakeDataSource()
        saveReminderViewModel =
            SaveReminderViewModel(ApplicationProvider.getApplicationContext(), fakeDataSource)
    }

    @After
    fun reset(){
        stopKoin()
    }

    @Test
    fun showSucceedSavedToast_validateAndSaveReminder() {
        val reminder = ReminderDataItem(
            "The second Location",
            "The main walkway is on the eastern side, and is open for use by both pedestrians and bicycles in the morning to mid-afternoon during weekdays (5:00 a.m. to 3:30 p.m.)",
            "Golden Gate Bridge",
            37.8199286,
            -122.47825510000001
        )
        saveReminderViewModel.validateAndSaveReminder(reminder)
        assertThat(saveReminderViewModel.showToast.getOrAwaitValue(), `is`("Reminder Saved !"))
    }

    @Test
    fun showLoadingMessage_savedReminderTest() = mainCoroutineRule.runBlockingTest {
        val reminder = ReminderDataItem(
            "The first location",
            "Opening times, ticket prices for individual and group visitors. Prices: 10.5 to 26.10 € maximum for adults, 2,6 to 13,10 € for children and young people.",
            "Eiffel tower",
            48.858093,
            2.294694
        )
        mainCoroutineRule.pauseDispatcher()
        saveReminderViewModel.validateAndSaveReminder(reminder)
        assertThat(saveReminderViewModel.showLoading.getOrAwaitValue(), `is`(true))
        mainCoroutineRule.resumeDispatcher()
        assertThat(saveReminderViewModel.showLoading.getOrAwaitValue(), `is`(false))
    }

    @Test
    fun showEmptyTitleError_validateAndSaveReminder() {
        val reminder = ReminderDataItem(
            "",
            "Opening times, ticket prices for individual and group visitors. Prices: 10.5 to 26.10 € maximum for adults, 2,6 to 13,10 € for children and young people.",
            "Eiffel tower",
            48.858093,
            2.294694
        )
        saveReminderViewModel.validateAndSaveReminder(reminder)
        assertThat(
            saveReminderViewModel.showSnackBarInt.getOrAwaitValue(), `is`(R.string.err_enter_title)
        )
    }

    @Test
    fun showSelectLocationError_validateAndSaveReminder() {
        val reminder = ReminderDataItem(
            "The first location",
            "Opening times, ticket prices for individual and group visitors. Prices: 10.5 to 26.10 € maximum for adults, 2,6 to 13,10 € for children and young people.",
            "",
            48.858093,
            2.294694
        )
        saveReminderViewModel.validateAndSaveReminder(reminder)
        assertThat(
            saveReminderViewModel.showSnackBarInt.getOrAwaitValue(),
            `is`(R.string.err_select_location)
        )
    }
}